globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/CT2i7cRfVVBYjAUbaqne3/_buildManifest.js",
    "static/CT2i7cRfVVBYjAUbaqne3/_ssgManifest.js",
    "static/CT2i7cRfVVBYjAUbaqne3/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0yb2wil16uz6h.js",
    "static/chunks/0o.wgcuo7oigu.js",
    "static/chunks/0.bgwaw9gkcqy.js",
    "static/chunks/0i8gv-72l8xrn.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/turbopack-0k-fxkm9kxg0q.js"
  ]
};
